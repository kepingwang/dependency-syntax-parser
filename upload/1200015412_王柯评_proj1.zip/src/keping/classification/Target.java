package keping.classification;

/**
 * The target output for classification.
 * @author wkp
 */
public abstract class Target implements java.io.Serializable {
    private static final long serialVersionUID = -6132346816790081099L;

}
