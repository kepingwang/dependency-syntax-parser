package keping.classification;


/**
 * The input for classification.
 * @author wkp
 */
public abstract class Input implements java.io.Serializable{
    private static final long serialVersionUID = 2851677102464390506L;
    
}
